Complete source code and instructions for "Code with us: Angular Quickstart" by John Papa and Ward Bell" is available on github at:

https://github.com/wardbell/code-with-us-angular-quickstart
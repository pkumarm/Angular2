export interface Person {
  id: number;
  name: string;
  height: number;
  weight: number;
}
